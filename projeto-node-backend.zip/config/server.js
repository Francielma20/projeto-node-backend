const express = require('express');

const consign = require('consign');

const bodyParser =  require('body-parser');

const server = express();

server.use(require('body-parser').json());

consign()
    .include('controllers')
    .into(server);


server.get('/hello', (req, res) =>{
    console.log("Acessando rota de teste do servidor")
    response.status(200);
    response.send('Olá Mundo!!!');
})

module.exports = server;